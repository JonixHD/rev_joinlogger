AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    print("[Join] Spieler verbindet: " .. name)
end)

AddEventHandler('playerJoined', function(source)
    Wait(1000) -- Gib dem Spiel etwas Zeit zum Laden

    local name = GetPlayerName(source)
    local ped = GetPlayerPed(source)
    local coords = GetEntityCoords(ped)
    local ip = GetPlayerEndpoint(source)

    print(("[Join] Spieler '%s' ist beigetreten bei Position: [X: %.2f, Y: %.2f, Z: %.2f]"):format(name, coords.x, coords.y, coords.z))
    print("[Info] IP-Adresse: " .. tostring(ip))

    print("[Info] Identifiers:")
    for k, v in ipairs(GetPlayerIdentifiers(source)) do
        print("   - " .. v)
    end
end)

AddEventHandler('playerDropped', function(reason)
    local source = source
    local name = GetPlayerName(source)
    local ped = GetPlayerPed(source)
    local coords = GetEntityCoords(ped)
    local ip = GetPlayerEndpoint(source)

    print(("[Leave] Spieler '%s' hat den Server verlassen bei Position: [X: %.2f, Y: %.2f, Z: %.2f] | Grund: %s"):format(name, coords.x, coords.y, coords.z, reason))
    print("[Info] IP-Adresse: " .. tostring(ip))

    print("[Info] Identifiers:")
    for k, v in ipairs(GetPlayerIdentifiers(source)) do
        print("   - " .. v)
    end
end)
