fx_version 'cerulean'
game 'gta5'

server_script 'server.lua'
